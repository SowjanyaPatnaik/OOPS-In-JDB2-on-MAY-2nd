
public class CalculateDAOImpl implements CacculateDAO {

	int result;
	@Override
	public int add(int fno, int sno) {
		// TODO Auto-generated method stub
		result=fno+sno;
		return result;
	}

	@Override
	public int sub(int fno, int sno) {
		// TODO Auto-generated method stub
		
		result=fno-sno;
		return result;
	}

	@Override
	public int mul(int fno, int sno) {
		// TODO Auto-generated method stub
		result=fno*sno;
		return result;
	}

}
