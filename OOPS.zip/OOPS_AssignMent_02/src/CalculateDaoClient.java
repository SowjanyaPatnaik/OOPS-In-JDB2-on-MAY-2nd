
public class CalculateDaoClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//sub class object obtain super class/interface
		CacculateDAO daoImpl=new CalculateDAOImpl();
	int result;	
	 result=	daoImpl.add(100,200);
	System.out.println("Addition of Two Numbers : "+result);
	result=	daoImpl.sub(500,300);
	System.out.println("Subtraction of Two Numbers : "+result);

	result=	daoImpl.mul(10,10);
	System.out.println("multiplation of Two Numbers : "+result);

	}

}
