
public interface CacculateDAO {

	int add(int fno,int sno);
	int sub(int fno,int sno);
	int mul(int fno,int sno);
}
