package com.book.inheri;

public class Book {
private int book_Id;
private String book_name;
private double book_price;
private String book_type;

public int getBook_Id() {
	return book_Id;
}
public void setBook_Id(int book_Id) {
	this.book_Id = book_Id;
}
public String getBook_name() {
	return book_name;
}
public void setBook_name(String book_name) {
	this.book_name = book_name;
}
public double getBook_price() {
	return book_price;
}
public void setBook_price(double book_price) {
	this.book_price = book_price;
}
public String getBook_type() {
	return book_type;
}
public void setBook_type(String book_type) {
	this.book_type = book_type;
}


}
