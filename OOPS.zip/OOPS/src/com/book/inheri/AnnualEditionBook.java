package com.book.inheri;

public class AnnualEditionBook extends Book{
	
	private int discount=20;

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}
	
	

}
