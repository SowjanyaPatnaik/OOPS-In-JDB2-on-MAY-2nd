package com.book.inheri;

public class BookClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Book b=new Book();
		b.setBook_Id(100);
		b.setBook_name("Java");
		b.setBook_type("Programming Language");
		b.setBook_price(2500);
		
	System.out.println(b.getBook_Id()+"\t"+b.getBook_name()+"\t"+b.getBook_type()+"\t"+b.getBook_price());
	
	
	SpecialEditionBook s=new SpecialEditionBook();
	s.setBook_Id(101);
	s.setBook_name("Hibernate");
	s.setBook_type("ORM");
	s.setBook_price(1500);
	s.setCds(2);
	
	System.out.println(s.getBook_Id()+"\t"+s.getBook_name()+"\t"+s.getBook_type()+"\t"+s.getBook_price()+"\t"+s.getCds());
	
		
		
	}

}
