package com.book.inheri;

public class SpecialEditionBook extends Book {

	private int cds=1;

	public int getCds() {
		return cds;
	}

	public void setCds(int cds) {
		this.cds = cds;
	}
	
}
