package com.methodover;

abstract class Bank
{
	public abstract int getrateOfInterest();
}

class ICICI extends Bank
{

	@Override
	public int getrateOfInterest() {
		// TODO Auto-generated method stub
		return 7;
	}
	
}

class Axis  extends Bank
{

	@Override
	public int getrateOfInterest() {
		// TODO Auto-generated method stub
		return 5;
	}
	
}

public class BankClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Axis ax=new Axis();
		System.out.println(ax.getrateOfInterest());
	}

}
