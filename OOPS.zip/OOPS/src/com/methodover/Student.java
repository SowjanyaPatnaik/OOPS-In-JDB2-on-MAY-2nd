package com.methodover;

public class Student {

	void display(int sno,String sname)
	{
		System.out.println(sno+"\t"+sname);
	}
	
	String display(String saddress,int age)
	{
		System.out.println(saddress+"\t"+age);
		
		return "ok BaBa";
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student stu=new Student();

String result=stu.display("hyd",25);



	}

}
