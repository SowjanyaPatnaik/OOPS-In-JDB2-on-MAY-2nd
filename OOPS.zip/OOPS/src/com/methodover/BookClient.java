package com.methodover;

public class BookClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnualEditionBook ae=new AnnualEditionBook(100,"HIberante","ORM",2500);
		ae.setDiscount(20);
		
		System.out.println(ae.getbId()+"\t"+ae.getbName()+"\t"+ae.getbType()+"\t"+ae.getbPrice()+"\t"+ae.getDiscount());
		
	}

}
