package com.methodover;

 class D {

	

}

 class H
{
	 
	 public static void main(String[]args)
	 {
		 System.out.println("hiiiiii");
	 }
	
}
