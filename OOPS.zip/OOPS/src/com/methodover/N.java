package com.methodover;

class M
{
	public M(int i) {
		// TODO Auto-generated constructor stub
		System.out.println("M Parameterized  Constructor");
	}
	
	public M() {
	
		// TODO Auto-generated constructor stub
		this(100);
		System.out.println("Default Constructor");
	}
}
public class N extends M{
	
	public N() {
		// TODO Auto-generated constructor stub
		//super()
		System.out.println("N Constructor");

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
N n=new N();
	}

}
