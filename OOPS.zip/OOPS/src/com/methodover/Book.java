package com.methodover;

public class Book {
	
	private int bId;
	private String bName;
	private String bType;
	private double bPrice;
	public Book(int bId, String bName, String bType, double bPrice) {
	//	super();
		this.bId = bId;
		this.bName = bName;
		this.bType = bType;
		this.bPrice = bPrice;
	}
	public int getbId() {
		return bId;
	}
	public String getbName() {
		return bName;
	}
	public String getbType() {
		return bType;
	}
	public double getbPrice() {
		return bPrice;
	}
	

}
