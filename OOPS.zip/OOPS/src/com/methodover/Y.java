package com.methodover;

interface Z
{
	void funZ();
}

public class Y {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Z z=new Z()
{

	@Override
	public void funZ() {
		// TODO Auto-generated method stub
		System.out.println("funZ");
	}
	
};

z.funZ();
	}

	

}
