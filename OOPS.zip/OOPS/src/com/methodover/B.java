package com.methodover;
class A
{
	void funA()
	{
		System.out.println("Parent class funA");
	}
	
	 void funB()
	{
		System.out.println("Parent class funB");
	}
}
public class B extends A{

	//we can access parent class Methods from sub class ? yes we can access
	//can we access parent class funA() from sub class Methods.
	void funA()
	{
		super.funB();
		super.funA();
		System.out.println("Overriden Method of  funA");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
B b=new B();
b.funA();

//b.funB();
	}

}
