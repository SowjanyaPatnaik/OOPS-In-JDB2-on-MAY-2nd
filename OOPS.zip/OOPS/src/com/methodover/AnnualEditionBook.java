package com.methodover;

public class AnnualEditionBook extends Book {

	public AnnualEditionBook(int bId, String bName, String bType, double bPrice) {
		super(bId, bName, bType, bPrice);
		// TODO Auto-generated constructor stub
	}
	
	private int discount;

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}
	

}
