
public class AccountClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account acc=new Account();
		acc.setOpening_Balance(35000);
		System.out.println(acc.getOpening_Balance());
	}

}
