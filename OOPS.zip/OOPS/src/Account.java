
public class Account {

	//data hiding
private	int opening_Balance=25000;

	public int getOpening_Balance() {
		return opening_Balance;
	}

	public void setOpening_Balance(int opening_Balance) {
		this.opening_Balance = opening_Balance;
	}
	
}
