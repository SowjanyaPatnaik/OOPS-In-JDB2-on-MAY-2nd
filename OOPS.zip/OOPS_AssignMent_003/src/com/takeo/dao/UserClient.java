package com.takeo.dao;

import java.util.Scanner;

import com.takeo.dao.impl.UserDAOImpl;
import com.takeo.model.User;

public class UserClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		UserDAO daoImpl = new UserDAOImpl();
		while (true) {
			System.out.println("***********************************************************");
			System.out.println("             1)Register                                    ");

			System.out.println("             2)Login                                    ");
			System.out.println("             3)Exit                                    ");

			System.out.println("***********************************************************");
			System.out.println("Enter The Choice");
			int choice = sc.nextInt();
			switch (choice) {

			case 1:

				daoImpl.register();

				break;

			case 2:
				System.out.println("Enter Email");
				String email = sc.next();
				System.out.println("Enter PassWord");
				String pass = sc.next();
				boolean flag = daoImpl.verifyUser(email, pass);

				if (flag)
					System.out.println("Valid User");
				else
					System.out.println("In Valid User");
				break;
			case 3:
				System.out.println("Thx for Using this App!");
				System.exit(0);

			default:
				System.out.println("Choose 1 to 3 Between");

			}// end of switch

		} // end of while
	}

}
