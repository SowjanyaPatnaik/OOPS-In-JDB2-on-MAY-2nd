package com.takeo.dao.impl;

import java.util.Scanner;

import com.takeo.dao.UserDAO;
import com.takeo.model.User;

public class UserDAOImpl implements UserDAO {
	Scanner sc = new Scanner(System.in);
	public static User addUsers[] = new User[3];

	@Override
	public void register() {
		// TODO Auto-generated method stub

		for (int i = 0; i < addUsers.length; ++i) {

			System.out.println("Enter First Name");
			String fname = sc.next();
			System.out.println("Enter Last Name");
			String lname = sc.next();
			System.out.println("Enter Email");
			String email = sc.next();
			System.out.println("Enter the Phone Number");
			long mn = sc.nextLong();
			System.out.println("Enter PassWord");
			String pass = sc.next();

			User user = new User(fname, lname, email, mn, pass);

			if (addUsers != null) {
				addUsers[i] = user;
				System.out.println("User Registred SuccessFully");
			}
		}

	}

	@Override
	public boolean verifyUser(String email, String password) {
		// TODO Auto-generated method stub

		for (int i = 0; i < addUsers.length; ++i) {
			if (addUsers[i].getEmail().equals(email) && addUsers[i].getPassword().equals(password)) {
				return true;
			}
		}

		return false;
	}

}
