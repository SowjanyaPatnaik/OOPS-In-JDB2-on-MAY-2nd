package com.takeo.dao;

import com.takeo.model.User;

public interface UserDAO {

	public void register();
	public boolean verifyUser(String email,String password);
}
