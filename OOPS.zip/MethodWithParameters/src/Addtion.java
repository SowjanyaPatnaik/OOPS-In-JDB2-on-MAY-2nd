
public class Addtion {

	int add(int fno,int sno)
	{
		int result=fno+sno;
		
		return result;
	}
	
	int [] funX()
	{
	int arr[]=	new int [3];
		
		return arr ;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addtion demo=new Addtion();
	int s=	demo.add(100, 200);
	System.out.println(s);
	}

}
