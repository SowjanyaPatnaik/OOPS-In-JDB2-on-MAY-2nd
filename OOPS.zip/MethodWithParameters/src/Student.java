
public class Student {

	void display(int sno,String sname)
	{
		System.out.println(sno+"\t"+sname);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stu=new Student();
		stu.display(100,"rani");
	}

}
