
public abstract class Student {
private int sId;
private String sName;
private String sAddress;
private String course;

public void setsId(int sId) {
	this.sId = sId;
}
public void setsName(String sName) {
	this.sName = sName;
}
public void setsAddress(String sAddress) {
	this.sAddress = sAddress;
}
public void setCourse(String course) {
	this.course = course;
}
public int getsId() {
	return sId;
}
public String getsName() {
	return sName;
}
public String getsAddress() {
	return sAddress;
}
public String getCourse() {
	return course;
}

public abstract int courseFee(String course);

}
