
public class FastTractBatch extends Student {

	@Override
	public int courseFee(String course) {
		// TODO Auto-generated method stub
		if(course.equals("Java"))
		return 50000;
		else if(course.equals("Testing"))
			return 25000;
		else
			return 15000;
	}

}
