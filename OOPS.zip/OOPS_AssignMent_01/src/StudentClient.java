
public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FastTractBatch ft=new FastTractBatch();
		ft.setsId(1);
		ft.setsName("rani");
		ft.setsAddress("usa");
		ft.setCourse("Java");
		
		int cfee=ft.courseFee(ft.getCourse());
		System.out.println(ft.getsId()+"\t"+ft.getsName()+"\t"+ft.getsAddress()+"\t"+ft.getCourse()+"\t"+cfee);
		
	}

}
