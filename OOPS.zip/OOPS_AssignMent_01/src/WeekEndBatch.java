
public class WeekEndBatch extends Student{

	@Override
	public int courseFee(String course) {
		// TODO Auto-generated method stub
		if(course.equals("Java"))
			return 75000;
			else if(course.equals("Testing"))
				return 35000;
			else
				return 25000;
		}

	}
